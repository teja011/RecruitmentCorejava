package com.cg.rms.service;

import java.util.List;

import com.cg.rms.dto.Recruitment;
import com.cg.rms.exception.RecruitmentException;

public interface CourseService {
	
	String insertCourse(Recruitment cource) throws RecruitmentException;
	List<Recruitment> getAllCourses() throws RecruitmentException;
	boolean updateCourse(Recruitment cource) throws RecruitmentException;
	/*boolean deleteCourse(long cource_id) throws CourseException;*/
	/*boolean validate(Course cource) throws CourseException;*/
}

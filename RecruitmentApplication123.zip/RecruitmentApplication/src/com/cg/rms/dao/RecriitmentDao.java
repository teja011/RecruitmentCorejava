package com.cg.rms.dao;

import java.util.List;


import com.cg.rms.dto.Recruitment;
import com.cg.rms.exception.RecruitmentException;

public interface RecriitmentDao {
	String insertCourse(Recruitment cource) throws RecruitmentException; 
	List<Recruitment> gatAllCourses() throws RecruitmentException;
	boolean updateCourse(Recruitment cource) throws RecruitmentException;
	public int login(String username, String password, String role)throws RecruitmentException;
	
}
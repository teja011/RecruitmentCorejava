package com.cg.rms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



import com.cg.rms.dto.Recruitment;
import com.cg.rms.exception.RecruitmentException;

public class RecruitmentDaoImpl implements RecriitmentDao {

	Connection conn;
	
	private String generateCourseId() throws RecruitmentException{
		
		conn = DBUtil.getConnection();
		String sql = "SELECT seq_course_id.NEXTVAL FROM DUAL";
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			rst.next();
			return rst.getString(1);
		} catch (SQLException e) {
			
			throw new RecruitmentException("problem in generating course Id"+e.getMessage());
			//e.printStackTrace();
		}
		
	
	}
	
	@Override
	public String insertCourse(Recruitment cource) throws RecruitmentException {
	String sql = "INSERT INTO cource values(?,?,?,?,?,?,?,?,?)";
	cource.setCandidate_id(generateCourseId());
	conn = DBUtil.getConnection();
	PreparedStatement pst;
	try {
		pst = conn.prepareStatement(sql);
		pst.setString(1, cource.getCandidate_id());
		pst.setString(2, cource.getCandidate_name());
		pst.setString(3, cource.getAddress());
		pst.setString(4, cource.getDOB());
		pst.setString(5, cource.getEmail_id());
		pst.setString(6, cource.getContact_number());
		pst.setString(7, cource.getMaritial_status());
		pst.setString(8, cource.getGender());
		pst.setString(9, cource.getPassport_number());
		
		
		pst.executeUpdate();
	} catch (SQLException e) {
		throw new RecruitmentException("problem in insering the deatails"+e.getMessage());
		//e.printStackTrace();
	}
	
		
		return cource.getCandidate_id();
	}

	@Override
	public List<Recruitment> gatAllCourses() throws RecruitmentException {
		String sql = "SELECT candidate_id,candidate_name, address, DOB, email_id, contact_number, Maritial_status, Gender, Passport_number FROM cource";
		ArrayList<Recruitment> clist = new ArrayList();
		conn = DBUtil.getConnection();
		
			Statement st;
			try {
				st = conn.createStatement();
				ResultSet rst = st.executeQuery(sql);
				while(rst.next()) {
					Recruitment c = new Recruitment();
					c.setCandidate_id(rst.getString("candidate_id"));
					c.setCandidate_name(rst.getString("candidate_name"));
					c.setAddress(rst.getString("address"));
					c.setDOB(rst.getString("DOB"));
					c.setEmail_id(rst.getString("email_id"));
					c.setContact_number(rst.getString("contact_number"));
					c.setMaritial_status(rst.getString("Maritial_status"));
					c.setGender(rst.getString("Gender"));
					c.setPassport_number(rst.getString("Passport_number"));
					clist.add(c);
				}
			} catch (SQLException e) {
				
				throw new RecruitmentException("problem in fetching the deatails"+e.getMessage());
				//e.printStackTrace();
			}
			return clist;
			
			}
			
			
		
		
	

	@Override
	public boolean updateCourse(Recruitment cource) throws RecruitmentException {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter candidate ID");
	String	id = sc.next();
	
	
	
	
		
		String sql = "UPDATE cource SET candidate_name =?, address=?, DOB =?, email_id=?, contact_number=?, Maritial_status=?, gender=?, Passport_number=? where candidate_id=?"; 
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		
		System.out.println("Enter the Details");
		System.out.println("Enter New Name of Candidate");
		String nm = sc.next();
		System.out.println("enter Address");
		String add = sc.next();
		System.out.println("enter DOB");
		String dob=sc.next();
		System.out.println("enter Email ID");
		String email=sc.next();
		System.out.println("enter contact no");
		String cno=sc.next();
		System.out.println("enter Maritial Status");
		String mstatus=sc.next();
		System.out.println("Enter your gender");
		String gender=sc.next();
		System.out.println("enter passport number");
		String pno=sc.next();
		
		try {
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, nm);
			pst.setString(2, add);
			pst.setString(3, dob);
			pst.setString(4, email);
			pst.setString(5, cno);
			pst.setString(6, mstatus);
			pst.setString(7, gender);
			pst.setString(8, pno);
			pst.setString(9, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new RecruitmentException("problem in updating the details"+e.getMessage());
			//e.printStackTrace();
		}
		return true;
		
			
	
		}

	@Override
	public int login(String username, String password, String role)
			throws RecruitmentException {
	
		try {
			conn=DBUtil.getConnection();
			String sql="select count(*) as COUNT from Recruitmentlogin where login_id=? and password=? and role=?";
			PreparedStatement pst;
			pst = conn.prepareStatement(sql);
			
		ResultSet rst;
			pst=conn.prepareStatement(sql);
			pst.setString(1,username);
			pst.setString(2,password);
			pst.setString(3,role);
			rst=pst.executeQuery();
			rst.next();
			int count=Integer.parseInt(rst.getString("COUNT"));
			if(count==1)
				
				return 1;
		} 
		catch (Exception e) 
		{
		
			e.printStackTrace();
			throw new RecruitmentException(e.getMessage());
		}
		
	
		return 2;
		
	}

	/*@Override
	public boolean deleteCourse(long course_id) throws CourseException {
		String sql = "delete from cource where course_id=?";
		conn = DBUtil.getConnection();
		PreparedStatement pst = null;
		try {
			pst = conn.prepareStatement(sql);
			pst.setLong(1, course_id);
			pst.executeUpdate();
		} catch (SQLException e) {
			
			throw new CourseException("problem in deleting the deatails"+e.getMessage());
		}
		
		
		return true;
	}*/

}
